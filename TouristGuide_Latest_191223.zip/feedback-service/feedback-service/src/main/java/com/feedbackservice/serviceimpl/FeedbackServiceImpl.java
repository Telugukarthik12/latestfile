package com.feedbackservice.serviceimpl;

import java.sql.Timestamp;
import java.util.List;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.feedbackservice.dto.FeedbackDto;
import com.feedbackservice.dto.UserDTO;
import com.feedbackservice.entity.Feedback;
import com.feedbackservice.openfeign.PlaceClient;
import com.feedbackservice.openfeign.UserClient;
import com.feedbackservice.repository.FeedbackRepository;
import com.feedbackservice.service.FeedbackService;

@Service
public class FeedbackServiceImpl implements FeedbackService {

	@Autowired
	FeedbackRepository feedbackrepo;

	/*
	 * @Autowired FeedbackInterface feedBackInterface;
	 */
	@Autowired
	PlaceClient placeClient;

	@Autowired
	UserClient userclient;

//	@Override
//	public Feedback saveFeedback(String userName,FeedbackDto feedbackDTO) {
//		
//		ResponseEntity<Integer> userIds = feedBackInterface.getUserName(userName);
//		
//		Feedback feedback = new Feedback();
//		feedback.setFeedbackText(feedbackDTO.getFeedbackText());
//
//		// Set Indian Standard Time (IST)
//		TimeZone timeZone = TimeZone.getTimeZone("Asia/Kolkata");
//		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//		timestamp.setTime(timestamp.getTime() + timeZone.getOffset(timestamp.getTime()));
//
//		feedback.setDateTime(timestamp);
//		feedback.setUserId(userIds);	// Use java.sql.Timestamp
//		return FeedbackRepository.save(feedback);
//	}

	/*
	 * @Override public Feedback saveFeedback(String userName, FeedbackDto
	 * feedbackDTO) { ResponseEntity<Integer> userIdsResponse =
	 * feedBackInterface.getUserName(userName);
	 * 
	 * Integer userId = userIdsResponse.getBody();
	 * 
	 * if (userId != null) { Feedback feedback = new Feedback();
	 * feedback.setFeedbackText(feedbackDTO.getFeedbackText());
	 * 
	 * // Set Indian Standard Time (IST) TimeZone timeZone =
	 * TimeZone.getTimeZone("Asia/Kolkata"); Timestamp timestamp = new
	 * Timestamp(System.currentTimeMillis()); timestamp.setTime(timestamp.getTime()
	 * + timeZone.getOffset(timestamp.getTime()));
	 * 
	 * feedback.setDateTime(timestamp); feedback.setUserId(userId); // Set the
	 * extracted userId return FeedbackRepository.save(feedback); } else { // Handle
	 * scenario when the user is not found or there's an issue return null; } }
	 */

	@Override
	public List<Feedback> getAllFeedback() {
		return feedbackrepo.findAll();
	}

	@Override
	public Feedback updateFeedback(Integer feedbackId, FeedbackDto feedbackDTO) {
		Feedback existingFeedback = feedbackrepo.findById(feedbackId).orElse(null);
		if (existingFeedback != null) {
			existingFeedback.setFeedbackText(feedbackDTO.getFeedbackText());

			// Set Indian Standard Time (IST)
			TimeZone timeZone = TimeZone.getTimeZone("Asia/Kolkata");
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			timestamp.setTime(timestamp.getTime() + timeZone.getOffset(timestamp.getTime()));
;
			existingFeedback.setDateTime(timestamp); // Use java.sql.Timestamp
			return feedbackrepo.save(existingFeedback);
		}
		return null; // Handle not found case
	}

	@Override
	public void deleteFeedback(Integer feedbackId) {
		feedbackrepo.deleteById(feedbackId);
	}

	@Override
	public Feedback getFeedback(Integer feedbackId) {
		return feedbackrepo.findById(feedbackId).orElse(null);
	}

	@Override
	public String getPlacefortour(Integer placeId, Integer userId, FeedbackDto feedbackdto) {
		Integer placeId1 = placeClient.getPlacefortour(placeId);
		Integer userId1 = userclient.getUserForClient(userId);
		Feedback feedback = new Feedback();
		feedback.setFeedbackText(feedbackdto.getFeedbackText());
		feedback.setDateTime(feedbackdto.getDateTime());
		feedback.setPlaceId(placeId1);
		feedback.setUserId(userId1);
		feedbackrepo.save(feedback);
		return "Created";
	}

	@Override
	public UserDTO getUserDTO(Integer feedbackId) {
		Feedback feedback = feedbackrepo.findById(feedbackId).get();
		Integer userid = feedback.getUserId();
		UserDTO userById = userclient.getUserById(userid).getBody();
		return userById;
	}

}
