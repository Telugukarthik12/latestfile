package com.tourplan.service;

import org.springframework.http.ResponseEntity;

import com.tourplan.dto.HelperDTO;
import com.tourplan.dto.TourRequest;

public interface TourPlanService {

	ResponseEntity<HelperDTO> getTourDetails(Integer tourId);

	ResponseEntity<String> createNewTour(Integer userId, TourRequest tourRequest);

	ResponseEntity<String> updateTour(Integer tourId, TourRequest tourRequest);

	ResponseEntity<String> deleteTour(Integer tourId);

}
