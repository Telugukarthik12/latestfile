package com.tourplan.dto;

import java.util.List;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class TourRequest {
	
	private TourPlanDTO tourPlanDto;
    private List<Integer> placeIds;


}
