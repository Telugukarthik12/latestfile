package com.tourplan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tourplan.dto.HelperDTO;
import com.tourplan.dto.TourRequest;
import com.tourplan.service.TourPlanService;

@RestController
@RequestMapping("/tourplan")
public class TourPlanController {

	@Autowired
	TourPlanService tourPlanService;

	@GetMapping("/gettourdetails/{tourId}")
	public ResponseEntity<HelperDTO> getTourDetails(@PathVariable(name = "tourId") Integer tourId) {
		return tourPlanService.getTourDetails(tourId);
	}

	@PostMapping("/createnewtour/{userId}")
	public ResponseEntity<String> createNewTour(@PathVariable(name = "userId") Integer userId,
			@RequestBody TourRequest tourRequest) {
		return tourPlanService.createNewTour(userId, tourRequest);
	}

	@PutMapping("/updateTour/{tourId}")
	public ResponseEntity<String> updateTour(@PathVariable(name = "tourId") Integer tourId,
			@RequestBody TourRequest tourRequest) {
		return tourPlanService.updateTour(tourId, tourRequest);
	}

	@DeleteMapping("/delete/{tourId}")
	public ResponseEntity<String> deleteTour(@PathVariable(name = "tourId") Integer tourId) {
		return tourPlanService.deleteTour(tourId);
	}
}
