package com.userservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.userservice.entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	User findByUserNameAndPassword(String username, String password);

	 Optional<User> findByUserName(String username);
}
