package com.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuristGuideeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TuristGuideeApplication.class, args);
	}

}
