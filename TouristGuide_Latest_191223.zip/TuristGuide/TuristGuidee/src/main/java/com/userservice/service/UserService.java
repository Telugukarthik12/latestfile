package com.userservice.service;

import java.util.List;

import com.userservice.dto.UserDTO;

public interface UserService {

	UserDTO registerUser(UserDTO userDTO);

	String signIn(String username, String password);

	UserDTO findUserById(Integer userId);

	//List<UserDTO> getAllUsers();

	UserDTO updateUser(Integer userId, UserDTO userDTO);

	List<UserDTO> getAllUsers();

	UserDTO findUserByName(String userName);

	Integer getUserForClient(Integer userId);

	



}
