package com.placeservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.placeservice.dto.PlaceDTO;
import com.placeservice.service.PlaceService;

@RestController
@RequestMapping("place")
public class PlaceController {

	@Autowired
	public PlaceService placeservice;

	@PostMapping("/addplace")
	public ResponseEntity<String> addPlace(@RequestBody PlaceDTO placeDto) {
		return placeservice.addPlace(placeDto);
	}

	@GetMapping("/getallplaces")
	public ResponseEntity<List<PlaceDTO>> getAllPlaces() {
		return placeservice.getAllPlaces();
	}

	@GetMapping("/getplacebyid/{placeId}")
	public ResponseEntity<PlaceDTO> getPlaceById(@PathVariable(name = "placeId") Integer placeId) throws Throwable {
		return new ResponseEntity<>(placeservice.getPlaceById(placeId), HttpStatus.OK);
	}

	@GetMapping("/getplacebyname/{placeName}")
	public ResponseEntity<PlaceDTO> getPlaceByName(@PathVariable(name = "placeName") String placeName) {
		return placeservice.getPlaceByName(placeName);
	}

	@GetMapping("/getplacebytags/{tags}")
	public ResponseEntity<PlaceDTO> getPlaceByTags(@PathVariable(name = "tags") String tags) {
		return placeservice.getPlaceByTags(tags);
	}

	@PutMapping("/updateplaces/{placeName}")
	public ResponseEntity<String> updatePlaces(@PathVariable(name = "placeName") String placeName,
			@RequestBody PlaceDTO placeDto) {
		return placeservice.updatePlaces(placeName, placeDto);
	}

	@DeleteMapping("/deletePlace/{placeName}")
	public ResponseEntity<String> deletePlace(@PathVariable(name = "placeName") String placeName) {
		return placeservice.deletePlace(placeName);
	}

//	client methods 

	@GetMapping("/getplacefortour/{placeId}")
	public Integer getPlacefortour(@PathVariable(name = "placeId") Integer placeId) {
		return placeservice.getPlacefortour(placeId);
	}

	/*
	 * @GetMapping("/getPlaceList") public ResponseEntity<List<Integer>>
	 * getPlaceList() { return placeservice.getPlaceList(); }
	 */

	@PostMapping("/getListOfPlacesById")
	public ResponseEntity<List<PlaceDTO>> getListOfPlaceDTOByPlaceId(@RequestBody List<Integer> placeIds) {
		return placeservice.getListOfPlaceDTOByPlaceId(placeIds);
	}

//	returns list of selected placeId's
	@PostMapping("/getListOfPlaceIds")
	public ResponseEntity<List<Integer>> getListOfPlaceIds(@RequestBody List<Integer> placeIds) {
		return placeservice.getListOfPlaceIdsl(placeIds);
	}
}
